Installation

1. Extract all contents of the zip folder.
2. Open the .exe file.
3. Enjoy!